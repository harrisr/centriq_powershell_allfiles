﻿# CorpSystemInfo.ps1

Import-Module CorpMod


function DisplayOSInfo
{
    $Data = Get-CorpOSInfo -ComputerName $SelectedSystem 

    $Output = "{0, -19} {1}`n -f 'Operating System:', $Data.OSVersion" +
              "{0, -19} {1}`n -f 'Service Pack:', $Data.SPVersion" +
              "{0, -19} {1}`n -f 'Manufacturer:', $Data.Manufacturer" +
              "{0, -19} {1}`n -f 'Model:', $Data.Model" +
              "{0, -19} {1}`n -f 'BIOS Serial Number:', $Data.BIOSSerial"

    return $Output

}


function DisplayDiskInfo
{
    $Data = Get-CorpDiskInfo -ComputerName $SelectedSystem 

    $Output = "{0, -5} {1, 8} {2, 8} {3, 8} {4, 8} {5, 8}`n" -f 
              'Drive', 'Size', 'Used', 'Avail', 'Capacity', 'FS'
    $Data | ForEach-Object {
        $Output +=
            "{0, -5} "    -f $_.Drive +
            "{0, 7:N2}G " -f ($_.Size / 1GB) +
            "{0, 7:N2}G " -f ($_.Used / 1GB) +
            "{0, 7:N2}G " -f ($_.Available / 1GB) +
            "{0, 7}% "    -f ($_.Capacity) +
            "{0, 8}`n "   -f ($_.FileSystem)

            
    }

    return $Output

}


function DisplayNICInso
{
    Write-Warning 'Not yet implemented'
}


do
{
    Clear-Host
    ''
    '(1) Display OS Info'
    '(2) Display Disk Info'
    '(Q) Quit'

    $choice = Read-Host -Prompt 'Select an action'

    switch ($choice)
    {
        '1' {
            DisplayOSInfo
            Wait-Key
        }
        '2' {
           DisplayDiskInfo
           Wait-Key
 
        }
        default {
            Write-Warning "$choice is an Invalid Selection - Please try again"
            Wait-Key
        }
    }

} while ($choice -ne 'q')

### while ($choice -cne 'q')
