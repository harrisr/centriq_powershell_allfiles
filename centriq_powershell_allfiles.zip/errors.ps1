﻿# Errors.ps1

Start-Transcript   c:\myfiles\log.log

#Import-Module Sql
#try {
#    Import-Module CorpMod1 -ErrorAction Stop
#    
#}
#catch {
#    Write-Warning "This script requires the module:  CorpMod1"
#    Exit 1
#}

$ErrorActionPreference = 'Stop'
#$ErrorActionPreference = 'Continue'
#$ErrorActionPreference = 'SilentlyContinue'

#trap [System.DivideByZeroException] {
#    "This is causing a problem."
#
#}

#trap  {
#    "This is a generic trap."
#
#}


#4 / 0


#Get-Content $dave    ###"C:\dave.txt"
#Get-Content dave  ###-ErrorAction  Stop


try
{
    # something bad could happen here
    #4 / 0
    Write-Host 'I AM HERE !!!!'
    Get-Content dave  ###-ErrorAction  Stop
}
#catch [System.DivideByZeroException]  {
#    'I will not divide by zero'
#    #$_
#    #$PSItem
#}
catch [System.Management.Automation.ItemNotFoundException]  {
    Write-Host   'zzzzzzzzzzzzzz'
    'Start wearing glasses'
    $PSItem
    #$_
    #$_.exception
}
#catch [System.UnauthorizedAccessException]  {
#    'Stop touching me !!!'
#}
catch   {
    Write-Host   'I hate old movie references'
}



Stop-Transcript